//
//  DQView.swift
//  DQ_User
//
//  Created by datxqv on 2/23/17.
//  Copyright © 2017 Paditech Inc. All rights reserved.
//

import UIKit

@IBDesignable
class FView: UIView {
    
     @IBInspectable var radius: CGFloat = 10.0 {
        
        didSet {
            
            var deltaX: CGFloat = 20.0
            let path = CGMutablePath()
            while deltaX + 2*radius < self.frame.size.width {
                
                
                path.addArc(center: CGPoint(x: deltaX, y: -radius), radius: radius, startAngle: 0.0, endAngle: 2 * 3.14, clockwise: false)
                deltaX = deltaX + 2*radius + 20
            }
            path.addRect(CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height))
            
            let maskLayer = CAShapeLayer()
            maskLayer.backgroundColor = UIColor.black.cgColor
            maskLayer.path = path
            maskLayer.fillRule = kCAFillRuleEvenOdd
            
            self.layer.mask = maskLayer
            self.clipsToBounds = true
            
            setNeedsDisplay()
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        
        didSet {
            self.layer.cornerRadius = cornerRadius
            setNeedsDisplay()
        }
    }
    
    @IBInspectable var borderColor: UIColor = UIColor.clear {
        
        didSet {
            self.layer.borderColor = borderColor.cgColor
            setNeedsDisplay()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0 {
        
        didSet {
            self.layer.borderWidth = borderWidth
            setNeedsDisplay()
        }
    }
    
}

extension UIView {
    
    internal func createOval(radius: CGFloat, startPosition: CGFloat = 20.0, distance: CGFloat = 20.0) {
        
        var deltaX: CGFloat = startPosition
        let path = CGMutablePath()
        
        while deltaX < self.frame.size.width {
            
            path.addArc(center: CGPoint(x: deltaX, y: 0), radius: radius, startAngle: 0.0, endAngle: 2 * 3.14, clockwise: false)
            deltaX = deltaX + 2*radius + distance
        }
        path.addRect(CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height))
        
        let maskLayer = CAShapeLayer()
        maskLayer.backgroundColor = UIColor.black.cgColor
        maskLayer.path = path
        maskLayer.fillRule = kCAFillRuleEvenOdd
        
        self.layer.mask = maskLayer
        self.clipsToBounds = true
        
        setNeedsDisplay()
    }
    
    internal func createOvalDefault() {
    
        let distance: CGFloat = 15.0
        let numberOval: CGFloat = 19.0
        let rate: CGFloat = 0.8
        let div: CGFloat = (numberOval - 1 + (numberOval-1)*rate)
        let radius: CGFloat = (self.frame.size.width - 2*distance)/div
        let distanceMid: CGFloat = radius*rate
        var deltaX: CGFloat = distance
        let path = CGMutablePath()
        for _ in 1...Int(numberOval) {
            path.addArc(center: CGPoint(x: deltaX, y: 1), radius: radius/2.0, startAngle: 0.0, endAngle: 2 * 3.14, clockwise: false)
            deltaX = deltaX + radius + distanceMid
        }
        
        path.addRect(CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height))
        
        let maskLayer = CAShapeLayer()
        maskLayer.backgroundColor = UIColor.black.cgColor
        maskLayer.path = path
        maskLayer.fillRule = kCAFillRuleEvenOdd
        
        self.layer.mask = maskLayer
        self.clipsToBounds = true
        
    }
}

extension UIView {
    
    internal func makeCorner(radius: CGFloat, borderWidth: CGFloat = 0.0, borderColor: UIColor? = nil) {
        self.layer.cornerRadius = radius
        self.layer.borderWidth = borderWidth
        if let color = borderColor {
            self.layer.borderColor = color.cgColor
        }
        self.layer.masksToBounds = radius > 0
    }
    
    internal func makeRound(borderWidth: CGFloat = 0.0, borderColor: UIColor? = nil) {
        self.makeCorner(radius: 0.5 * self.frame.height, borderWidth: borderWidth, borderColor: borderColor)
    }
    
    func imageSnap() -> UIImage {
        UIGraphicsBeginImageContextWithOptions(bounds.size, isOpaque, 0)
        guard let context = UIGraphicsGetCurrentContext() else {
            return UIImage()
        }
        layer.render(in: context)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
}
