//
//  JLabel.swift
//  JLPTLearning
//
//  Created by Trần An on 6/21/17.
//  Copyright © 2017 Paditech. All rights reserved.
//

import UIKit

class JLabel: UILabel {

    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = cornerRadius
            setNeedsDisplay()

        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            self.layer.borderWidth = borderWidth
            setNeedsDisplay()

        }
    }
    @IBInspectable var borderColor: UIColor? {
        didSet {
            self.layer.borderColor = borderColor?.cgColor
            setNeedsDisplay()

        }
    }
    
    @IBInspectable var masksToBounds: Bool = false {
        didSet {
            self.layer.masksToBounds = masksToBounds
            setNeedsDisplay()

        }
    }
}
