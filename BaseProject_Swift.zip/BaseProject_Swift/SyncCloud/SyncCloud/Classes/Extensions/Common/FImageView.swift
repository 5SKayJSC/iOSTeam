//
//  DQImageView.swift
//  DQ_User
//
//  Created by datxqv on 3/21/17.
//  Copyright © 2017 Paditech Inc. All rights reserved.
//

import UIKit

class DQImageView: UIImageView {

    @IBInspectable var cornerRadius: CGFloat = 0 {
        
        didSet {
            self.layer.cornerRadius = cornerRadius
            setNeedsDisplay()
        }
    }
    
    @IBInspectable var borderColor: UIColor = UIColor.clear {
        
        didSet {
            self.layer.borderColor = borderColor.cgColor
            setNeedsDisplay()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0 {
        
        didSet {
            self.layer.borderWidth = borderWidth
            setNeedsDisplay()
        }
    }

}
